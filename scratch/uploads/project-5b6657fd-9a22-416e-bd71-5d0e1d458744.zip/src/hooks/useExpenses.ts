import {useEffect,useState} from 'react';import {Expense} from '../types/expense';
export function useExpenses(){const [items,setItems]=useState<Expense[]>(()=>JSON.parse(localStorage.getItem('expenses')||'[]'));
useEffect(()=>localStorage.setItem('expenses',JSON.stringify(items)),[items]);
return {items,add:(e:Expense)=>setItems(v=>[e,...v]),remove:(id:string)=>setItems(v=>v.filter(x=>x.id!==id))};}