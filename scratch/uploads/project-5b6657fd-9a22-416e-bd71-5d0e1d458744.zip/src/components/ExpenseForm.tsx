import {useState} from 'react';
export default function ExpenseForm({onAdd}:{onAdd:(e:any)=>void}){const[s,set]=useState({title:'',amount:'',category:'General',date:''});
return <form onSubmit={e=>{e.preventDefault();onAdd({...s,id:crypto.randomUUID(),amount:+s.amount});set({title:'',amount:'',category:'General',date:''})}}>
<input placeholder='Title' value={s.title} onChange={e=>set({...s,title:e.target.value})}/>
<input type='number' placeholder='Amount' value={s.amount} onChange={e=>set({...s,amount:e.target.value})}/>
<input placeholder='Category' value={s.category} onChange={e=>set({...s,category:e.target.value})}/>
<input type='date' value={s.date} onChange={e=>set({...s,date:e.target.value})}/>
<button>Add</button></form>}