# Expense Tracker

Senior folder structure:
src/
  components/
  hooks/
  pages/
  services/
  types/
  utils/

Features:
- React + TypeScript + Vite
- LocalStorage persistence
- Add/Delete expenses
- Running total

Suggested production improvements:
- Redux Toolkit or Zustand
- React Query
- Form validation (React Hook Form + Zod)
- Charts
- Authentication
- Backend (FastAPI/Node)
- Unit tests
