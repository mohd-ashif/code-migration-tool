import {useState} from "react";
type Todo={id:number;text:string;done:boolean};
export default function App(){
 const [text,setText]=useState("");
 const [todos,setTodos]=useState<Todo[]>([]);
 const add=()=>{if(!text.trim())return;setTodos([...todos,{id:Date.now(),text,done:false}]);setText("");};
 const toggle=(id:number)=>setTodos(todos.map(t=>t.id===id?{...t,done:!t.done}:t));
 return <div style={{maxWidth:500,margin:"40px auto",fontFamily:"Arial"}}>
 <h1>React TS Todo</h1>
 <input value={text} onChange={e=>setText(e.target.value)} placeholder="Task"/>
 <button onClick={add}>Add</button>
 <ul>{todos.map(t=><li key={t.id}><label><input type="checkbox" checked={t.done} onChange={()=>toggle(t.id)}/> <span style={{textDecoration:t.done?"line-through":"none"}}>{t.text}</span></label></li>)}</ul>
 </div>;
}
